import { Component, OnDestroy, inject } from '@angular/core';
import { ToastService } from 'src/app/shared/toast/toast.service';
import { HttpClient } from '@angular/common/http';
import { finalize, Subject, takeUntil, timer } from 'rxjs';
import { Taxpayer } from '../../../../models/taxpayer.model';
import { Router } from '@angular/router';
import { API_ENDPOINTS } from '../../../../core/constants/api.constants';
import { NoticeCreateRequest } from '../../../../models/notice.model';

@Component({
  selector: 'app-notice-create',
  templateUrl: './notice-create.component.html',
  styleUrls: ['./notice-create.component.css'],
})
export class NoticeCreateComponent implements OnDestroy {
  isLoading = false;

  // Taxpayer search
  searchQuery = '';
  isSearching = false;
  searchResults: Taxpayer[] = [];
  selectedTaxpayer: Taxpayer | null = null;
  showResults = false;
  private destroy$ = new Subject<void>();
  successMsg = '';
  errorMsg = '';

  noticeTypes = [
    'General',
    'Tax Due',
    'Audit Notice',
    'Penalty Notice',
    'Compliance',
    'Refund Update',
    'System',
    'Reminder',
  ];
  priorities = ['Low', 'Normal', 'High', 'Urgent'];
  targetTypes = [
    'All Taxpayers',
    'Specific Taxpayer',
    'Tax Officers',
    'Auditors',
    'All Users',
  ];
  officers = [
    'Tax Officer',
    'Senior Tax Officer',
    'Tax Commissioner',
    'NBR',
    'System Admin',
  ];

  form: NoticeCreateRequest = {
    subject: '',
    body: '',
    noticeType: '',
    priority: 'Normal',
    targetType: 'All Taxpayers',
    taxpayerId: null,
    issuedBy: '',
    issuedDate: new Date().toISOString().split('T')[0],
    dueDate: '',
    attachmentName: '',
  };

  get showTaxpayerFields(): boolean {
    return this.form.targetType === 'Specific Taxpayer';
  }

  isFormValid(): boolean {
    return !!(
      this.form.subject &&
      this.form.body &&
      this.form.noticeType &&
      this.form.issuedBy
    );
  }

  constructor(
    private http: HttpClient,
    private router: Router,
    private toast: ToastService,
  ) {}

  onSubmit(): void {
    if (!this.isFormValid()) {
      this.errorMsg = 'Please fill in all required fields.';
      this.toast.error('Please fill in all required fields.');
      return;
    }

    this.isLoading = true;
    this.errorMsg = '';
    this.successMsg = '';

    this.http.post(API_ENDPOINTS.NOTICES.CREATE, this.form)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
      next: () => {
        this.isLoading = false;
        this.successMsg = 'Notice sent successfully!';
        this.toast.success('Notice sent successfully!');
        timer(1500).pipe(takeUntil(this.destroy$))
          .subscribe(() => this.router.navigate(['/notices']));
      },
      error: () => {
        this.isLoading = false;
        this.successMsg = '';
        this.errorMsg = 'Failed to send notice. Please try again.';
        this.toast.error('Failed to send notice. Please try again.');
      },
    });
  }

  onReset(): void {
    this.form = {
      subject: '',
      body: '',
      noticeType: '',
      priority: 'Normal',
      targetType: 'All Taxpayers',
      taxpayerId: null,
      issuedBy: '',
      issuedDate: new Date().toISOString().split('T')[0],
      dueDate: '',
      attachmentName: '',
    };
    this.errorMsg = '';
    this.successMsg = '';
  }

  onCancel(): void {
    this.router.navigate(['/notices']);
  }

  // ── Taxpayer Search ──────────────────────────────────────────────────────
  searchTaxpayer(): void {
    const q = this.searchQuery.trim();
    if (!q || q.length < 3) {
      return;
    }
    this.isSearching = true;
    this.http
      .get<Taxpayer[]>(
        API_ENDPOINTS.TAXPAYERS.LIST + '?search=' + encodeURIComponent(q),
      )
      .pipe(
        takeUntil(this.destroy$),
        finalize(() => (this.isSearching = false)),
      )
      .subscribe({
        next: (d) => {
          this.searchResults = d;
          this.showResults = true;
        },
        error: () => {},
      });
  }

  selectTaxpayer(t: Taxpayer): void {
    this.selectedTaxpayer = t;
    this.form.taxpayerId = t.id ?? null;
    this.showResults = false;
  }

  clearTaxpayer(): void {
    this.selectedTaxpayer = null;
    this.form.taxpayerId = null;
    this.searchQuery = '';
    this.searchResults = [];
    this.showResults = false;
  }

  getDisplayName(t: Taxpayer): string {
    return t.taxpayerType?.typeName?.toLowerCase().includes('company')
      ? t.companyName || ''
      : t.fullName || '';
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
